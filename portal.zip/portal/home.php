<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
	<input type="button" value="MAIN REGISTRATION DESK" id="MRDlogin" onclick="window.location.href='MRDlogin.php'" >

	<input type="button" value=" REGISTRATION DESK" id="RDlogin" onclick="window.location.href='RDlogin.php'" >

	<input type="button" value="COORDINATOR REGISTRATION DESK" id="CRDlogin" onclick="window.location.href='CRDlogin.php'" >

	<input type="button" value="CALCULATOR" id="calculate" onclick="window.location.href='RDcalcu.php'" >

	<input type="button" value="PUBG" id="pubg" onclick="window.location.href='pubglogin.php'" >




</body>
</html>