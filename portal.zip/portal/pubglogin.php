<?php
include_once('connect.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>PUBG TYPE</title>
</head>
<body>
	<form id="select">
		<input type="button" value="SOLO" id="SOLO" onclick="window.location.href='pubgsolo.php'" >

		<input type="button" value="SQUAD" id="SQUAD" onclick="window.location.href='pubgsquad.php'" >	

	</form>
</body>
</html>